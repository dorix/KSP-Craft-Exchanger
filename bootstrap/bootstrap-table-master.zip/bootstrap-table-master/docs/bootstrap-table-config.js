/**
 * Bootstrap Table Config
 */
(function ($) {
    'use strict';

    $.extend($.fn.bootstrapTable.defaults, {

    });

    $.extend($.fn.bootstrapTable.columnDefaults, {
        align: 'center',
        valign: 'middle'
    });
})(jQuery);