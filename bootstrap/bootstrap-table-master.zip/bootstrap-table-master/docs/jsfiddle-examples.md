## JSFiddle Examples

* Nested data: [http://jsfiddle.net/8svjf80g/3/](http://jsfiddle.net/8svjf80g/3/)
* Multiple Fields in Column: [http://jsfiddle.net/a9a4yxqw/1/](http://jsfiddle.net/a9a4yxqw/1/)
* Remove row data use modal: [http://jsfiddle.net/1314arL3/1/](http://jsfiddle.net/1314arL3/1/)
* JSONP data: [http://jsfiddle.net/wenyi/8svjf80g/33/](http://jsfiddle.net/wenyi/8svjf80g/33/)
* Custom scrollbar: [http://plnkr.co/edit/IHnFAiVh0gfcmBdy05Mt?p=preview](http://plnkr.co/edit/IHnFAiVh0gfcmBdy05Mt?p=preview)
